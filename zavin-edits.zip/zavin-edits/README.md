# Zavin Edits: portfolio site

## Run on your PC
1. Install Node.js (nodejs.org, LTS)
2. In this folder:  `npm install`  then  `npm start`
3. Public site: http://localhost:3000   Admin (only you): http://localhost:3000/admin

## Change your password (IMPORTANT)
Default is `zavin123`. Set your own:
- Windows (CMD):  `set ADMIN_PASSWORD=myStrongPass && npm start`
- Mac/Linux:      `ADMIN_PASSWORD=myStrongPass npm start`

Edit your name, about, email, Instagram in `public/config.js`.
